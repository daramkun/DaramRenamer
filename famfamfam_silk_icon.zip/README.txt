== FamFamFam Silk Icon ToolBar Icon Pack for Daram Renamer ==
=== Installation and Apply ===
1. Do Not unzip this icon pack. Just copy to same directory of Daram Renamer.
2. Open DaramRenamer.config.json, and Edit "toolbar_icon_pack" element from null or other to "famfamfam_silk_icon".

=== License ===
FamFamFam silk icon follow Creative Commons Attribution 2.5 License.
http://www.famfamfam.com/lab/icons/silk/